package com.sadadib.billtracker.data;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class BillViewModel extends ViewModel {
    private final MutableLiveData<String[]> billData;

    public BillViewModel() {
        billData = new MutableLiveData<>();
    }

    public void updateBillData(String[] list) {
        billData.setValue(list);
    }

    public LiveData<String[]> getBillData() {
        return billData;
    }

    private void fillData() {
        String[] data = new String[20];

        for (int i = 0; i < data.length; i++) {
            data[i] = "Item at index" + i;
        }

        updateBillData(data);
    }
}

