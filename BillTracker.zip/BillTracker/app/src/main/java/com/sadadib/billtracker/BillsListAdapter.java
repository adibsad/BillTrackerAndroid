package com.sadadib.billtracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class BillsListAdapter extends RecyclerView.Adapter<BillsListAdapter.BillViewHolder> {
    private String[] mDataSet;

    public static class BillViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public TextView textView;

        public BillViewHolder(View v) {
            super(v);
            textView = (TextView) v.findViewById(R.id.bill_item_title);
        }
    }

    public BillsListAdapter(String[] data) {
        mDataSet = data;
    }

    public BillsListAdapter.BillViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.bill_row, parent, false);

        BillViewHolder vh = new BillViewHolder(v);
        return vh;
    }

    public void onBindViewHolder(BillViewHolder holder, int position) {

    }

    public int getItemCount() {
        return mDataSet.length;
    }
}
